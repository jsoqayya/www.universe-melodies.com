#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
إصلاح جميع المشاكل المذكورة:
1. الفصل 4: حذف الأزرار القديمة
2. الفصل 12: تغيير نص الزر من "الإدراك المتصل" إلى "الفصل السابق"
3. الفصل 14 و 15: التحقق من التكرار وحذفه
"""

import os
import re

def fix_chapter4():
    """إصلاح الفصل الرابع - حذف أزرار قديمة إن وجدت"""
    filepath = '/home/user/universe-melodies-website/chapter4.html'
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # حذف أي أزرار قديمة بتصميم btn class
    old_pattern = r'<a href="[^"]*" class="btn[^"]*">[^<]*</a>\s*'
    new_content = re.sub(old_pattern, '', content)
    
    if new_content != content:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(new_content)
        print("✅ chapter4.html - تم حذف الأزرار القديمة")
        return True
    else:
        print("⚪ chapter4.html - نظيف بالفعل")
        return False

def fix_chapter12():
    """إصلاح الفصل 12 - تغيير نص الزر"""
    filepath = '/home/user/universe-melodies-website/chapter12.html'
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # استبدال "الفصل السابق: الإدراك المتصل" بـ "الفصل السابق"
    new_content = content.replace(
        '<span>الفصل السابق: الإدراك المتصل</span>',
        '<span>← الفصل السابق</span>'
    )
    
    # أيضاً تغيير أي نص آخر مشابه
    new_content = new_content.replace(
        'الفصل السابق: الإدراك المتصل',
        'الفصل السابق'
    )
    
    if new_content != content:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(new_content)
        print("✅ chapter12.html - تم تغيير نص الزر")
        return True
    else:
        print("⚪ chapter12.html - النص صحيح بالفعل")
        return False

def check_and_fix_duplicates(chapter_num):
    """التحقق من التكرار وإصلاحه للفصول 14 و 15"""
    filepath = f'/home/user/universe-melodies-website/chapter{chapter_num}.html'
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # البحث عن جميع أقسام التعليقات
    pattern = r'<!-- قسم التعليقات الموحد -->.*?</script>'
    matches = list(re.finditer(pattern, content, re.DOTALL))
    
    if len(matches) > 1:
        print(f"⚠️ chapter{chapter_num}.html - وجدت {len(matches)} مربع تعليقات!")
        
        # نحتفظ بآخر مربع فقط (الأحدث)
        # نحذف الأولى
        for i in range(len(matches) - 1):
            content = content.replace(matches[i].group(), '', 1)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"✅ chapter{chapter_num}.html - تم حذف المربعات المكررة")
        return True
    else:
        print(f"⚪ chapter{chapter_num}.html - مربع تعليق واحد فقط (صحيح)")
        return False

def main():
    print("=" * 70)
    print("بدء إصلاح جميع المشاكل...")
    print("=" * 70)
    print()
    
    # إصلاح الفصل 4
    print("1️⃣ الفصل الرابع:")
    fix_chapter4()
    print()
    
    # إصلاح الفصل 12
    print("2️⃣ الفصل الثاني عشر:")
    fix_chapter12()
    print()
    
    # التحقق من الفصول 14 و 15
    print("3️⃣ الفصل الرابع عشر:")
    check_and_fix_duplicates(14)
    print()
    
    print("4️⃣ الفصل الخامس عشر:")
    check_and_fix_duplicates(15)
    print()
    
    print("=" * 70)
    print("✅ اكتمل الإصلاح!")
    print("=" * 70)

if __name__ == '__main__':
    main()

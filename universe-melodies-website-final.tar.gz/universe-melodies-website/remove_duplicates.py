#!/usr/bin/env python3
import re
import os

# Chapters to check for duplicates (6-15)
chapters = [f'chapter{i}.html' for i in range(6, 16)]

success_count = 0
for chapter in chapters:
    if not os.path.exists(chapter):
        print(f"❌ File not found: {chapter}")
        continue
    
    with open(chapter, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Count occurrences of comments section
    comments_pattern = r'<!-- Comments Section with Interactive Form -->'
    comments_count = len(re.findall(comments_pattern, content))
    
    # Count occurrences of navigation buttons
    nav_pattern = r'<!-- Navigation Buttons -->'
    nav_count = len(re.findall(nav_pattern, content))
    
    print(f"\n📄 {chapter}:")
    print(f"   Comments sections found: {comments_count}")
    print(f"   Navigation buttons found: {nav_count}")
    
    if comments_count > 1 or nav_count > 1:
        print(f"   ⚠️ Duplicates detected! Removing extras...")
        
        # Keep only the LAST occurrence of comments section
        # Find all matches with their positions
        matches = list(re.finditer(
            r'<!-- Comments Section with Interactive Form -->.*?</script>\s*',
            content,
            flags=re.DOTALL
        ))
        
        if len(matches) > 1:
            # Remove all except the last one
            for match in matches[:-1]:
                content = content[:match.start()] + content[match.end():]
                # Need to re-search after each removal since positions change
                content_temp = content
                matches = list(re.finditer(
                    r'<!-- Comments Section with Interactive Form -->.*?</script>\s*',
                    content_temp,
                    flags=re.DOTALL
                ))
            print(f"   ✅ Removed {comments_count - 1} duplicate comment section(s)")
        
        # Keep only the LAST occurrence of navigation buttons
        matches = list(re.finditer(
            r'<!-- Navigation Buttons -->.*?(?=</body>|<!-- Responsive CSS -->)',
            content,
            flags=re.DOTALL
        ))
        
        if len(matches) > 1:
            # Remove all except the last one
            for match in matches[:-1]:
                content = content[:match.start()] + content[match.end():]
                # Re-search after removal
                content_temp = content
                matches = list(re.finditer(
                    r'<!-- Navigation Buttons -->.*?(?=</body>|<!-- Responsive CSS -->)',
                    content_temp,
                    flags=re.DOTALL
                ))
            print(f"   ✅ Removed {nav_count - 1} duplicate navigation section(s)")
        
        # Save the cleaned content
        with open(chapter, 'w', encoding='utf-8') as f:
            f.write(content)
        
        success_count += 1
        print(f"   ✅ {chapter} cleaned successfully")
    else:
        print(f"   ✅ No duplicates found")

print(f"\n🎉 Processed {len(chapters)} chapters, cleaned {success_count} files")

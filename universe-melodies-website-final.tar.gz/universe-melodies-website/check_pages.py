#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
فحص الصفحات لمعرفة أي منها لا يحتوي على أزرار التنقل أو مربع التعليقات
"""

import os

pages = [
    'introduction.html',
    'chapter1.html', 'chapter2.html', 'chapter3.html', 'chapter4.html', 'chapter5.html',
    'chapter6.html', 'chapter7.html', 'chapter8.html', 'chapter9.html', 'chapter10.html',
    'chapter11.html', 'chapter12.html', 'chapter13.html', 'chapter14.html', 'chapter15.html',
    'conclusion.html'
]

pages_without_nav = []
pages_without_comments = []

print("=" * 70)
print("فحص الصفحات...")
print("=" * 70)

for page in pages:
    filepath = os.path.join('/home/user/universe-melodies-website', page)
    
    if not os.path.exists(filepath):
        print(f"⚠️ {page} - غير موجود")
        continue
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # البحث عن أزرار التنقل
    has_nav = ('الفصل السابق' in content or 
               'الفصل التالي' in content or 
               'الصفحة الرئيسية' in content or
               'الفصل الرابع' in content or
               'الفصل السادس' in content)
    
    # البحث عن مربع التعليقات
    has_comments = ('شاركنا رأيك' in content or 
                    'شاركنا تأملاتك' in content or
                    'commentBox' in content or 
                    'commentInput' in content)
    
    status = ""
    if not has_nav:
        status += "❌ لا يوجد أزرار"
        pages_without_nav.append(page)
    else:
        status += "✅ يوجد أزرار"
    
    status += " | "
    
    if not has_comments:
        status += "❌ لا يوجد تعليقات"
        pages_without_comments.append(page)
    else:
        status += "✅ يوجد تعليقات"
    
    print(f"{page:20s} : {status}")

print("=" * 70)
print(f"\n📋 ملخص:")
print(f"الصفحات بدون أزرار تنقل: {len(pages_without_nav)}")
for p in pages_without_nav:
    print(f"  • {p}")

print(f"\nالصفحات بدون مربع تعليقات: {len(pages_without_comments)}")
for p in pages_without_comments:
    print(f"  • {p}")

print("\n" + "=" * 70)
print("✅ الصفحات التي تحتاج إضافة (بدون أزرار وبدون تعليقات):")
needs_both = set(pages_without_nav) & set(pages_without_comments)
for p in needs_both:
    print(f"  🎯 {p}")
print("=" * 70)

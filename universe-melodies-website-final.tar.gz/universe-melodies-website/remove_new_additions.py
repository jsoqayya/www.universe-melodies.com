#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
حذف الأزرار الجديدة التي أضفتها (بتصميم gradient) 
من الفصول 5 و 8 و 9 والاحتفاظ بالتصميم الأصلي
"""

import re

chapters = [5, 8, 9]

print("=" * 70)
print("حذف الأزرار الجديدة المضافة...")
print("=" * 70)

for ch in chapters:
    filepath = f'/home/user/universe-melodies-website/chapter{ch}.html'
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # البحث عن الأزرار الجديدة (التي تحتوي على style inline طويل)
    # نبحث عن div مع style="max-width: 900px; margin: 40px auto
    pattern = r'<div style="max-width: 900px; margin: 40px auto.*?</div>\s*</div>'
    
    new_content = re.sub(pattern, '', content, flags=re.DOTALL)
    
    if new_content != content:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(new_content)
        print(f"✅ chapter{ch}.html - تم حذف الأزرار الجديدة")
    else:
        print(f"⚪ chapter{ch}.html - لم يتم العثور على أزرار جديدة")

print("\n" + "=" * 70)
print("✅ اكتمل!")
print("=" * 70)

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
إضافة أزرار تنقل موحدة للفصل 8 و 9
"""

NAV_TEMPLATE_CHAPTER8 = """
<!-- أزرار التنقل الموحدة -->
<div style="display: flex; justify-content: space-between; align-items: center; max-width: 900px; margin: 60px auto 40px auto; padding: 25px; background: linear-gradient(135deg, #F5F7FA 0%, #E8EEF2 100%); border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); direction: rtl;">
    <a href="chapter7.html" style="display: inline-flex; align-items: center; padding: 12px 30px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; text-decoration: none; border-radius: 10px; font-family: 'Tajawal', sans-serif; font-weight: bold; font-size: 1.1em; transition: all 0.3s; box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 6px 20px rgba(102, 126, 234, 0.6)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 15px rgba(102, 126, 234, 0.4)'">
        ← الفصل السابق
    </a>
    
    <a href="contents.html" style="display: inline-flex; flex-direction: column; align-items: center; padding: 12px 30px; background: white; color: #2C3E50; text-decoration: none; border-radius: 10px; border: 2px solid #3498DB; font-family: 'Tajawal', sans-serif; font-weight: bold; transition: all 0.3s;" onmouseover="this.style.background='#3498DB'; this.style.color='white'" onmouseout="this.style.background='white'; this.style.color='#2C3E50'">
        🏠 الصفحة الرئيسية
    </a>
    
    <a href="chapter9.html" style="display: inline-flex; align-items: center; padding: 12px 30px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; text-decoration: none; border-radius: 10px; font-family: 'Tajawal', sans-serif; font-weight: bold; font-size: 1.1em; transition: all 0.3s; box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 6px 20px rgba(102, 126, 234, 0.6)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 15px rgba(102, 126, 234, 0.4)'">
        الفصل التالي →
    </a>
</div>
"""

NAV_TEMPLATE_CHAPTER9 = """
<!-- أزرار التنقل الموحدة -->
<div style="display: flex; justify-content: space-between; align-items: center; max-width: 900px; margin: 60px auto 40px auto; padding: 25px; background: linear-gradient(135deg, #F5F7FA 0%, #E8EEF2 100%); border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); direction: rtl;">
    <a href="chapter8.html" style="display: inline-flex; align-items: center; padding: 12px 30px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; text-decoration: none; border-radius: 10px; font-family: 'Tajawal', sans-serif; font-weight: bold; font-size: 1.1em; transition: all 0.3s; box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 6px 20px rgba(102, 126, 234, 0.6)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 15px rgba(102, 126, 234, 0.4)'">
        ← الفصل السابق
    </a>
    
    <a href="contents.html" style="display: inline-flex; flex-direction: column; align-items: center; padding: 12px 30px; background: white; color: #2C3E50; text-decoration: none; border-radius: 10px; border: 2px solid #3498DB; font-family: 'Tajawal', sans-serif; font-weight: bold; transition: all 0.3s;" onmouseover="this.style.background='#3498DB'; this.style.color='white'" onmouseout="this.style.background='white'; this.style.color='#2C3E50'">
        🏠 الصفحة الرئيسية
    </a>
    
    <a href="chapter10.html" style="display: inline-flex; align-items: center; padding: 12px 30px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; text-decoration: none; border-radius: 10px; font-family: 'Tajawal', sans-serif; font-weight: bold; font-size: 1.1em; transition: all 0.3s; box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 6px 20px rgba(102, 126, 234, 0.6)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 15px rgba(102, 126, 234, 0.4)'">
        الفصل التالي →
    </a>
</div>
"""

def add_nav_to_chapter(filename, nav_template):
    """إضافة أزرار التنقل قبل قسم التعليقات أو قبل </body>"""
    with open(filename, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # حاول الإضافة قبل قسم التعليقات
    if '<!-- قسم التعليقات الموحد -->' in content:
        content = content.replace('<!-- قسم التعليقات الموحد -->', nav_template + '\n<!-- قسم التعليقات الموحد -->', 1)
    else:
        # أضف قبل </body>
        content = content.replace('</body>', nav_template + '\n</body>', 1)
    
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"✅ {filename}: تمت إضافة أزرار التنقل")

def main():
    print("🚀 إضافة أزرار التنقل للفصل 8 و 9...\n")
    add_nav_to_chapter('chapter8.html', NAV_TEMPLATE_CHAPTER8)
    add_nav_to_chapter('chapter9.html', NAV_TEMPLATE_CHAPTER9)
    print("\n✅ تم الانتهاء بنجاح!")

if __name__ == '__main__':
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script to add language switch button SAFELY without touching design or content.
Only adds a fixed position button after <body> tag.
"""

import os
import re

# Language switch button HTML - minimal and non-intrusive
LANGUAGE_SWITCH_HTML = '''
<!-- Language Switch Button - Added for bilingual support -->
<a href="en/{filename}" style="
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 9999;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 10px 20px;
    border-radius: 25px;
    text-decoration: none;
    font-weight: 600;
    font-size: 14px;
    box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    gap: 8px;
" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 6px 20px rgba(102, 126, 234, 0.6)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 15px rgba(102, 126, 234, 0.4)'">
    <span>🌐</span>
    <span>English Version</span>
</a>
'''

# Pages to update
pages = ['introduction.html'] + [f'chapter{i}.html' for i in range(1, 16)] + ['conclusion.html']

print("=" * 70)
print("🔧 إضافة زر التبديل للغة - بدون المساس بالتصميم")
print("=" * 70)

success_count = 0
for page in pages:
    if not os.path.exists(page):
        print(f"⚠️  {page}: ملف غير موجود")
        continue
    
    # Read file
    with open(page, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check if button already exists
    if 'Language Switch Button' in content or 'English Version' in content:
        print(f"✓  {page}: الزر موجود مسبقاً")
        continue
    
    # Find <body> tag and add button right after it
    # Using regex to find <body> and insert after it
    pattern = r'(<body[^>]*>)'
    
    if re.search(pattern, content):
        # Create the button HTML with correct filename
        button_html = LANGUAGE_SWITCH_HTML.replace('{filename}', page)
        
        # Insert button after <body> tag
        new_content = re.sub(
            pattern,
            r'\1' + button_html,
            content,
            count=1
        )
        
        # Write back
        with open(page, 'w', encoding='utf-8') as f:
            f.write(new_content)
        
        print(f"✅ {page}: تمت الإضافة بنجاح")
        success_count += 1
    else:
        print(f"⚠️  {page}: لم يتم العثور على <body> tag")

print("=" * 70)
print(f"✅ النتيجة: تم تحديث {success_count} من {len(pages)} صفحة")
print("=" * 70)
print()
print("📋 ملاحظات:")
print("  - الزر يظهر في الزاوية العلوية اليمنى")
print("  - لا يؤثر على التصميم الأصلي أبداً")
print("  - لا يغير أي نص أو محتوى")
print("  - فقط إضافة زر floating")

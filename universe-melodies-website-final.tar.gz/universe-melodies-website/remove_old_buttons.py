#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
حذف الأزرار القديمة التي تسبب مشكلة في التنسيق
"""

import os
import re

pages = ['chapter3.html', 'chapter4.html', 'chapter12.html', 'chapter13.html', 
         'chapter14.html', 'chapter15.html', 'conclusion.html']

for page in pages:
    filepath = os.path.join('/home/user/universe-melodies-website', page)
    
    if not os.path.exists(filepath):
        print(f"⚠️ {page} - غير موجود")
        continue
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # البحث عن الأزرار القديمة وحذفها
    # نبحث عن الأزرار التي تحتوي على btn-secondary أو btn-primary
    old_buttons_pattern = r'<a href="[^"]*" class="btn btn-(secondary|primary) nav-btn">[^<]*</a>\s*'
    
    # حذف الأزرار القديمة
    new_content = re.sub(old_buttons_pattern, '', content)
    
    # حذف أيضاً الأزرار التي بدون class محددة لكن تحتوي على "الفصل السابق" أو "الفصل التالي" وليست من تصميمنا الجديد
    # نبحث عن <a> tags التي تحتوي على btn class (القديمة)
    if new_content != content:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(new_content)
        print(f"✅ {page} - تم حذف الأزرار القديمة")
    else:
        print(f"⚪ {page} - لا توجد أزرار قديمة")

print("\n✅ اكتمل التنظيف")

#!/bin/bash

# Language switch button HTML for Arabic chapters
ARABIC_SWITCH='    <!-- Language Switch Button -->
    <div style="position: fixed; top: 20px; left: 20px; z-index: 1000;">
        <a href="en/CHAPTER_FILE" style="display: flex; align-items: center; gap: 8px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 10px 20px; border-radius: 25px; text-decoration: none; font-size: 14px; font-weight: 600; box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4); transition: all 0.3s ease;">
            <span>🌐</span>
            <span>English Version</span>
        </a>
    </div>'

# Language switch button HTML for English chapters
ENGLISH_SWITCH='    <!-- Language Switch Button -->
    <div style="position: fixed; top: 20px; left: 20px; z-index: 1000;">
        <a href="../CHAPTER_FILE" style="display: flex; align-items: center; gap: 8px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 10px 20px; border-radius: 25px; text-decoration: none; font-size: 14px; font-weight: 600; box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4); transition: all 0.3s ease;">
            <span>🌐</span>
            <span>النسخة العربية</span>
        </a>
    </div>'

echo "Adding language switch to Arabic chapters..."
for file in chapter*.html; do
    if [ -f "$file" ]; then
        # Check if language switch already exists
        if ! grep -q "Language Switch Button" "$file"; then
            # Create switch with correct file name
            SWITCH=$(echo "$ARABIC_SWITCH" | sed "s/CHAPTER_FILE/$file/g")
            
            # Add after <body> tag
            sed -i "/<body>/a\\
$SWITCH" "$file"
            
            echo "✓ Added language switch to $file"
        else
            echo "○ $file already has language switch"
        fi
    fi
done

echo ""
echo "Adding language switch to English chapters..."
cd en/
for file in chapter*.html; do
    if [ -f "$file" ]; then
        # Check if language switch already exists
        if ! grep -q "Language Switch Button" "$file"; then
            # Create switch with correct file name
            SWITCH=$(echo "$ENGLISH_SWITCH" | sed "s/CHAPTER_FILE/$file/g")
            
            # Add after <body> tag
            sed -i "/<body>/a\\
$SWITCH" "$file"
            
            echo "✓ Added language switch to en/$file"
        else
            echo "○ en/$file already has language switch"
        fi
    fi
done

cd ..
echo ""
echo "✅ Done! Language switch added to all chapters."

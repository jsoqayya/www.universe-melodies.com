#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
تطبيق نموذج موحد لأزرار التنقل ومربع التعليقات على جميع الصفحات العربية
مع حذف الأزرار والتعليقات القديمة
"""

import re
import os

# القالب الموحد
UNIFIED_FOOTER_TEMPLATE = """
    <!-- قسم التعليقات الموحد -->
    <div style="max-width: 900px; margin: 60px auto; padding: 30px; background: linear-gradient(135deg, rgba(139, 69, 255, 0.1), rgba(59, 130, 246, 0.1)); border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); direction: rtl;">
        <h3 style="text-align: center; color: #8b45ff; font-size: 28px; margin-bottom: 20px; font-family: 'Amiri', serif;">
            💬 شاركنا رأيك
        </h3>
        <textarea id="commentBox" placeholder="اكتب تعليقك هنا..." style="width: 100%; min-height: 150px; padding: 15px; border: 2px solid #8b45ff; border-radius: 12px; font-size: 16px; font-family: 'Tajawal', sans-serif; resize: vertical; direction: rtl; transition: all 0.3s;" onfocus="this.style.borderColor='#3b82f6'; this.style.boxShadow='0 0 15px rgba(139, 69, 255, 0.3)';" onblur="this.style.borderColor='#8b45ff'; this.style.boxShadow='none';"></textarea>
        <button onclick="submitComment()" style="display: block; margin: 20px auto 0; padding: 12px 40px; background: linear-gradient(135deg, #8b45ff, #3b82f6); color: white; border: none; border-radius: 25px; font-size: 18px; font-weight: bold; cursor: pointer; transition: all 0.3s; font-family: 'Tajawal', sans-serif;" onmouseover="this.style.transform='translateY(-3px)'; this.style.boxShadow='0 10px 25px rgba(139, 69, 255, 0.4)';" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none';">
            ✉️ أرسل تعليقك
        </button>
        <div id="commentStatus" style="margin-top: 15px; text-align: center; font-size: 16px; font-family: 'Tajawal', sans-serif;"></div>
    </div>

    <script>
    function submitComment() {
        const commentBox = document.getElementById('commentBox');
        const statusDiv = document.getElementById('commentStatus');
        const comment = commentBox.value.trim();
        
        if (comment === '') {
            statusDiv.innerHTML = '<span style="color: #ef4444;">⚠️ الرجاء كتابة تعليق قبل الإرسال</span>';
            setTimeout(() => { statusDiv.innerHTML = ''; }, 3000);
            return;
        }
        
        statusDiv.innerHTML = '<span style="color: #10b981;">✅ شكراً لك! تم استلام تعليقك بنجاح</span>';
        commentBox.value = '';
        
        setTimeout(() => { statusDiv.innerHTML = ''; }, 4000);
    }
    </script>

    <!-- أزرار التنقل الموحدة -->
    <div style="max-width: 900px; margin: 40px auto 60px; padding: 20px; text-align: center; direction: rtl;">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
            <a href="{prev_link}" style="flex: 1; min-width: 150px; padding: 12px 25px; background: linear-gradient(135deg, #8b45ff, #3b82f6); color: white; text-decoration: none; border-radius: 25px; font-size: 16px; font-weight: bold; font-family: 'Tajawal', sans-serif; transition: all 0.3s; display: inline-block; text-align: center;" onmouseover="this.style.transform='translateY(-3px)'; this.style.boxShadow='0 10px 25px rgba(139, 69, 255, 0.4)';" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none';">
                ← الفصل السابق
            </a>
            <a href="index.html" style="flex: 1; min-width: 150px; padding: 12px 25px; background: linear-gradient(135deg, #ec4899, #f43f5e); color: white; text-decoration: none; border-radius: 25px; font-size: 16px; font-weight: bold; font-family: 'Tajawal', sans-serif; transition: all 0.3s; display: inline-block; text-align: center;" onmouseover="this.style.transform='translateY(-3px)'; this.style.boxShadow='0 10px 25px rgba(236, 72, 153, 0.4)';" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none';">
                🏠 الصفحة الرئيسية
            </a>
            <a href="{next_link}" style="flex: 1; min-width: 150px; padding: 12px 25px; background: linear-gradient(135deg, #8b45ff, #3b82f6); color: white; text-decoration: none; border-radius: 25px; font-size: 16px; font-weight: bold; font-family: 'Tajawal', sans-serif; transition: all 0.3s; display: inline-block; text-align: center;" onmouseover="this.style.transform='translateY(-3px)'; this.style.boxShadow='0 10px 25px rgba(139, 69, 255, 0.4)';" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none';">
                الفصل التالي →
            </a>
        </div>
    </div>
"""

# تحديد روابط التنقل لكل صفحة
NAVIGATION_LINKS = {
    'introduction.html': {'prev': 'index.html', 'next': 'chapter1.html'},
    'chapter1.html': {'prev': 'introduction.html', 'next': 'chapter2.html'},
    'chapter2.html': {'prev': 'chapter1.html', 'next': 'chapter3.html'},
    'chapter3.html': {'prev': 'chapter2.html', 'next': 'chapter4.html'},
    'chapter4.html': {'prev': 'chapter3.html', 'next': 'chapter5.html'},
    'chapter5.html': {'prev': 'chapter4.html', 'next': 'chapter6.html'},
    'chapter6.html': {'prev': 'chapter5.html', 'next': 'chapter7.html'},
    'chapter7.html': {'prev': 'chapter6.html', 'next': 'chapter8.html'},
    'chapter8.html': {'prev': 'chapter7.html', 'next': 'chapter9.html'},
    'chapter9.html': {'prev': 'chapter8.html', 'next': 'chapter10.html'},
    'chapter10.html': {'prev': 'chapter9.html', 'next': 'chapter11.html'},
    'chapter11.html': {'prev': 'chapter10.html', 'next': 'chapter12.html'},
    'chapter12.html': {'prev': 'chapter11.html', 'next': 'chapter13.html'},
    'chapter13.html': {'prev': 'chapter12.html', 'next': 'chapter14.html'},
    'chapter14.html': {'prev': 'chapter13.html', 'next': 'chapter15.html'},
    'chapter15.html': {'prev': 'chapter14.html', 'next': 'conclusion.html'},
    'conclusion.html': {'prev': 'chapter15.html', 'next': 'index.html'},
}

def remove_old_elements(html_content):
    """حذف الأزرار القديمة ومربعات التعليقات القديمة"""
    
    # حذف أي قسم تعليقات قديم (يحتوي على شاركنا رأيك أو textarea)
    # نبحث عن div يحتوي على شاركنا رأيك ونحذفه مع محتوياته
    html_content = re.sub(
        r'<div[^>]*>[\s\S]*?شاركنا رأيك[\s\S]*?</div>\s*(?:</div>\s*)*(?:<script>[\s\S]*?submitComment[\s\S]*?</script>)?',
        '',
        html_content,
        flags=re.IGNORECASE | re.MULTILINE
    )
    
    # حذف أزرار التنقل القديمة (أي div يحتوي على "الفصل السابق" أو "الفصل التالي")
    html_content = re.sub(
        r'<div[^>]*>[\s\S]*?(الفصل السابق|الفصل التالي|الصفحة الرئيسية)[\s\S]*?</div>\s*(?:</div>\s*)*',
        '',
        html_content,
        flags=re.IGNORECASE | re.MULTILINE
    )
    
    # حذف أي script يحتوي على submitComment
    html_content = re.sub(
        r'<script[^>]*>[\s\S]*?submitComment[\s\S]*?</script>',
        '',
        html_content,
        flags=re.IGNORECASE
    )
    
    return html_content

def apply_unified_footer(filename):
    """تطبيق القالب الموحد على صفحة واحدة"""
    
    if filename not in NAVIGATION_LINKS:
        print(f"⚠️ تخطي {filename} - ليس في القائمة")
        return False
    
    filepath = os.path.join('/home/user/universe-melodies-website', filename)
    
    if not os.path.exists(filepath):
        print(f"❌ {filename} غير موجود")
        return False
    
    # قراءة المحتوى
    with open(filepath, 'r', encoding='utf-8') as f:
        html_content = f.read()
    
    # حذف العناصر القديمة
    html_content = remove_old_elements(html_content)
    
    # إعداد القالب بالروابط المناسبة
    links = NAVIGATION_LINKS[filename]
    footer = UNIFIED_FOOTER_TEMPLATE.replace('{prev_link}', links['prev']).replace('{next_link}', links['next'])
    
    # إضافة القالب الجديد قبل </body>
    if '</body>' in html_content:
        html_content = html_content.replace('</body>', footer + '\n</body>')
    else:
        # إذا لم يوجد </body>، نضيفه في النهاية
        html_content += footer + '\n</body>\n</html>'
    
    # حفظ الملف
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    print(f"✅ {filename} تم تحديثه")
    return True

def main():
    """تطبيق على جميع الصفحات"""
    pages = [
        'introduction.html',
        'chapter1.html', 'chapter2.html', 'chapter3.html', 'chapter4.html', 'chapter5.html',
        'chapter6.html', 'chapter7.html', 'chapter8.html', 'chapter9.html', 'chapter10.html',
        'chapter11.html', 'chapter12.html', 'chapter13.html', 'chapter14.html', 'chapter15.html',
        'conclusion.html'
    ]
    
    success_count = 0
    total = len(pages)
    
    print("=" * 60)
    print("بدء تطبيق النموذج الموحد...")
    print("=" * 60)
    
    for page in pages:
        if apply_unified_footer(page):
            success_count += 1
    
    print("=" * 60)
    print(f"✅ اكتمل: {success_count}/{total} صفحة تم تحديثها بنجاح")
    print("=" * 60)

if __name__ == '__main__':
    main()

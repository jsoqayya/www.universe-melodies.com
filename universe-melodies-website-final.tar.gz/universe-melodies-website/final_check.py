#!/usr/bin/env python3
import re
import os

print("=" * 70)
print("🔍 Final Check: Comments & Navigation Sections")
print("=" * 70)

# Check all chapters 6-15
chapters = [f'chapter{i}.html' for i in range(6, 16)]

all_good = True
for chapter in chapters:
    if not os.path.exists(chapter):
        print(f"❌ File not found: {chapter}")
        continue
    
    with open(chapter, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Count actual interactive comment boxes (with textarea)
    comment_box_count = content.count('💬 شاركنا برأيك')
    
    # Count navigation button sections
    nav_button_count = content.count('<!-- Navigation Buttons -->')
    
    # Count the submit button
    submit_button_count = content.count('✉️ أرسل تعليقك')
    
    print(f"\n📄 {chapter}:")
    print(f"   💬 Comment boxes: {comment_box_count}")
    print(f"   ✉️ Submit buttons: {submit_button_count}")
    print(f"   🧭 Navigation sections: {nav_button_count}")
    
    if comment_box_count == 1 and nav_button_count == 1 and submit_button_count == 1:
        print(f"   ✅ Perfect! One of each element")
    else:
        print(f"   ⚠️ Warning: Unexpected counts detected")
        all_good = False
        
        # Show where they appear
        lines = content.split('\n')
        for i, line in enumerate(lines, 1):
            if '💬 شاركنا برأيك' in line:
                print(f"      Comment box at line {i}")
            if '<!-- Navigation Buttons -->' in line:
                print(f"      Navigation at line {i}")

print("\n" + "=" * 70)
if all_good:
    print("✅ All chapters are perfect! No duplicates found.")
else:
    print("⚠️ Some chapters have issues that need attention.")
print("=" * 70)

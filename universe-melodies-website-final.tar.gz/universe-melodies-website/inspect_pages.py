#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
المرحلة 1: فحص الصفحات فقط - لا تغيير
"""

import os
import re

# Pages to inspect
pages = ['introduction.html'] + [f'chapter{i}.html' for i in range(1, 16)] + ['conclusion.html']

print("=" * 80)
print("🔍 المرحلة 1: فحص الصفحات - لا تغيير")
print("=" * 80)
print()

results = []

for page in pages:
    if not os.path.exists(page):
        continue
    
    with open(page, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Search for navigation buttons
    has_prev_button = bool(re.search(r'الفصل السابق|Previous Chapter|السابق', content, re.IGNORECASE))
    has_next_button = bool(re.search(r'الفصل التالي|Next Chapter|التالي', content, re.IGNORECASE))
    has_home_button = bool(re.search(r'الرئيسية|الصفحة الرئيسية|Home.*href=', content, re.IGNORECASE))
    
    # Search for comments section
    has_comments = bool(re.search(r'شاركنا رأيك|شاركنا برأيك|تعليقات|Comments', content, re.IGNORECASE))
    has_comment_box = bool(re.search(r'<textarea|commentBox|comment-box', content, re.IGNORECASE))
    has_submit_button = bool(re.search(r'أرسل تعليقك|إرسال|Submit.*Comment', content, re.IGNORECASE))
    
    # Count number of times found
    prev_count = len(re.findall(r'الفصل السابق|Previous Chapter|السابق', content, re.IGNORECASE))
    next_count = len(re.findall(r'الفصل التالي|Next Chapter|التالي', content, re.IGNORECASE))
    home_count = len(re.findall(r'الرئيسية|الصفحة الرئيسية', content, re.IGNORECASE))
    comments_count = len(re.findall(r'شاركنا رأيك|شاركنا برأيك', content, re.IGNORECASE))
    
    result = {
        'page': page,
        'has_prev': has_prev_button,
        'has_next': has_next_button,
        'has_home': has_home_button,
        'has_comments': has_comments,
        'has_comment_box': has_comment_box,
        'has_submit_button': has_submit_button,
        'prev_count': prev_count,
        'next_count': next_count,
        'home_count': home_count,
        'comments_count': comments_count
    }
    results.append(result)
    
    print(f"📄 {page}:")
    print(f"   أزرار التنقل:")
    print(f"      - زر السابق: {'✓' if has_prev_button else '✗'} (عدد: {prev_count})")
    print(f"      - زر التالي: {'✓' if has_next_button else '✗'} (عدد: {next_count})")
    print(f"      - زر الرئيسية: {'✓' if has_home_button else '✗'} (عدد: {home_count})")
    print(f"   قسم التعليقات:")
    print(f"      - عنوان 'شاركنا رأيك': {'✓' if has_comments else '✗'} (عدد: {comments_count})")
    print(f"      - مربع نص (textarea): {'✓' if has_comment_box else '✗'}")
    print(f"      - زر إرسال: {'✓' if has_submit_button else '✗'}")
    print()

print("=" * 80)
print("📊 ملخص النتائج:")
print("=" * 80)

# Summary
pages_with_nav = sum(1 for r in results if r['has_prev'] or r['has_next'] or r['has_home'])
pages_with_comments = sum(1 for r in results if r['has_comments'])
pages_with_comment_box = sum(1 for r in results if r['has_comment_box'])
pages_without_nav = len(results) - pages_with_nav
pages_without_comments = len(results) - pages_with_comments

print(f"✓ الصفحات التي تحتوي على أزرار تنقل: {pages_with_nav}/{len(results)}")
print(f"✗ الصفحات التي لا تحتوي على أزرار تنقل: {pages_without_nav}/{len(results)}")
print(f"✓ الصفحات التي تحتوي على قسم تعليقات: {pages_with_comments}/{len(results)}")
print(f"✓ الصفحات التي تحتوي على مربع تعليقات: {pages_with_comment_box}/{len(results)}")
print(f"✗ الصفحات التي لا تحتوي على تعليقات: {pages_without_comments}/{len(results)}")
print()

# Detailed recommendations
print("=" * 80)
print("💡 التوصيات:")
print("=" * 80)

if pages_without_nav == len(results):
    print("✅ لا توجد أزرار تنقل في أي صفحة - يمكن الإضافة بأمان")
elif pages_without_nav == 0:
    print("⚠️  جميع الصفحات تحتوي على أزرار تنقل - يجب الحذف أولاً")
else:
    print(f"⚠️  بعض الصفحات ({pages_with_nav}) تحتوي على أزرار والبعض ({pages_without_nav}) لا")
    print("   يجب توحيد الجميع - حذف القديم وإضافة نموذج موحد")

print()

if pages_without_comments == len(results):
    print("✅ لا توجد أقسام تعليقات في أي صفحة - يمكن الإضافة بأمان")
elif pages_without_comments == 0:
    print("⚠️  جميع الصفحات تحتوي على أقسام تعليقات - يجب الحذف أولاً")
else:
    print(f"⚠️  بعض الصفحات ({pages_with_comments}) تحتوي على تعليقات والبعض ({pages_without_comments}) لا")
    print("   يجب توحيد الجميع - حذف القديم وإضافة نموذج موحد")

print()
print("=" * 80)
print("✅ انتهى الفحص - لم يتم تغيير أي شيء")
print("=" * 80)

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
إضافة مربع تعليقات موحد للفصول التي تفتقر إليه.
"""

import re

PAGES_NEED_COMMENTS = [
    'chapter3.html',
    'chapter4.html',
    'chapter5.html',
    'chapter8.html',
    'chapter9.html',
    'chapter12.html',
    'chapter13.html',
    'chapter14.html'
]

UNIFIED_COMMENTS_TEMPLATE = """
<!-- قسم التعليقات الموحد -->
<div style="max-width: 900px; margin: 60px auto; padding: 30px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 20px; box-shadow: 0 8px 32px rgba(0,0,0,0.1); direction: rtl;">
    <h3 style="color: white; text-align: right; font-family: 'Amiri', 'Tajawal', serif; margin-bottom: 25px; font-size: 1.8em; text-shadow: 2px 2px 4px rgba(0,0,0,0.2);">
        💬 شاركنا رأيك
    </h3>
    
    <textarea 
        id="commentBox" 
        placeholder="اكتب تعليقك هنا..."
        style="
            width: 100%;
            min-height: 150px;
            padding: 20px;
            border: 2px solid rgba(255,255,255,0.3);
            border-radius: 15px;
            font-size: 1.1em;
            font-family: 'Tajawal', sans-serif;
            direction: rtl;
            resize: vertical;
            background: rgba(255,255,255,0.95);
            color: #2c3e50;
            transition: all 0.3s ease;
            box-sizing: border-box;
        "
        onfocus="this.style.borderColor='#ffffff'; this.style.boxShadow='0 0 20px rgba(255,255,255,0.5)'"
        onblur="this.style.borderColor='rgba(255,255,255,0.3)'; this.style.boxShadow='none'"
    ></textarea>
    
    <button 
        onclick="submitComment()" 
        style="
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            border: none;
            padding: 15px 40px;
            font-size: 1.2em;
            font-family: 'Tajawal', sans-serif;
            border-radius: 25px;
            cursor: pointer;
            margin-top: 20px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
            font-weight: bold;
        "
        onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 6px 20px rgba(0,0,0,0.3)'"
        onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 15px rgba(0,0,0,0.2)'"
    >
        ✉️ أرسل تعليقك
    </button>
    
    <div id="commentStatus" style="margin-top: 20px; padding: 15px; border-radius: 10px; display: none; font-family: 'Tajawal', sans-serif;"></div>
</div>

<script>
function submitComment() {
    const commentBox = document.getElementById('commentBox');
    const statusDiv = document.getElementById('commentStatus');
    const comment = commentBox.value.trim();
    
    if (!comment) {
        statusDiv.style.display = 'block';
        statusDiv.style.background = 'rgba(255, 193, 7, 0.9)';
        statusDiv.style.color = '#000';
        statusDiv.innerHTML = '⚠️ الرجاء كتابة تعليق قبل الإرسال';
        setTimeout(() => {
            statusDiv.style.display = 'none';
        }, 3000);
        return;
    }
    
    // هنا يمكن إضافة كود إرسال التعليق إلى السيرفر
    statusDiv.style.display = 'block';
    statusDiv.style.background = 'rgba(76, 175, 80, 0.9)';
    statusDiv.style.color = 'white';
    statusDiv.innerHTML = '✅ شكراً لك! تم استلام تعليقك بنجاح';
    commentBox.value = '';
    
    setTimeout(() => {
        statusDiv.style.display = 'none';
    }, 4000);
}
</script>
"""

def add_comments_to_page(filename):
    """إضافة مربع تعليقات قبل </body>"""
    with open(filename, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # تحقق إن كان يوجد مربع تعليقات بالفعل
    if 'شاركنا رأيك' in content or 'شاركنا تأملاتك' in content:
        print(f"⚠️  {filename}: يوجد مربع تعليقات بالفعل - تم التخطي")
        return False
    
    # أضف مربع التعليقات قبل </body>
    if '</body>' in content:
        content = content.replace('</body>', UNIFIED_COMMENTS_TEMPLATE + '\n</body>', 1)
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"✅ {filename}: تمت إضافة مربع التعليقات")
        return True
    else:
        print(f"❌ {filename}: لم يتم العثور على </body>")
        return False

def main():
    print("🚀 بدء إضافة مربعات التعليقات للفصول الناقصة...\n")
    
    success_count = 0
    for page in PAGES_NEED_COMMENTS:
        if add_comments_to_page(page):
            success_count += 1
    
    print(f"\n✅ تمت إضافة مربعات التعليقات لـ {success_count}/{len(PAGES_NEED_COMMENTS)} صفحة")

if __name__ == '__main__':
    main()

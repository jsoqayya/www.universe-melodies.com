#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
حذف أقسام التعليقات القديمة والاحتفاظ بالموحد الجديد فقط
"""

import re

def remove_old_comments_section(filepath):
    """حذف قسم التعليقات القديم"""
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # البحث عن القسم القديم الذي يبدأ بـ <!-- قسم التعليقات -->
    # وينتهي قبل <!-- قسم التعليقات الموحد -->
    
    # نبحث عن القسم القديم: من <!-- قسم التعليقات --> حتى </section> التي تليها
    # لكن ليس "الموحد"
    old_pattern = r'<!-- قسم التعليقات -->\s*<section[^>]*>.*?</section>\s*(?=<!-- قسم التعليقات الموحد|</div>\s*</section>|$)'
    
    new_content = re.sub(old_pattern, '', content, flags=re.DOTALL)
    
    if new_content != content:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(new_content)
        return True
    return False

# إصلاح الفصل 14
print("إصلاح الفصل 14...")
if remove_old_comments_section('/home/user/universe-melodies-website/chapter14.html'):
    print("✅ chapter14.html - تم حذف قسم التعليقات القديم")
else:
    print("⚪ chapter14.html - لم يتم العثور على قسم قديم")

# إصلاح الفصل 15
print("\nإصلاح الفصل 15...")
if remove_old_comments_section('/home/user/universe-melodies-website/chapter15.html'):
    print("✅ chapter15.html - تم حذف قسم التعليقات القديم")
else:
    print("⚪ chapter15.html - لم يتم العثور على قسم قديم")

print("\n✅ اكتمل!")

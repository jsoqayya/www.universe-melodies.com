#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
إضافة مربع التعليقات فقط للصفحات التي لديها أزرار لكن بدون تعليقات
"""

import os
import shutil

# قالب مربع التعليقات فقط (بدون أزرار)
COMMENTS_TEMPLATE = """
    <!-- قسم التعليقات الموحد -->
    <div style="max-width: 900px; margin: 60px auto; padding: 30px; background: linear-gradient(135deg, rgba(139, 69, 255, 0.1), rgba(59, 130, 246, 0.1)); border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); direction: rtl;">
        <h3 style="text-align: center; color: #8b45ff; font-size: 28px; margin-bottom: 20px; font-family: 'Amiri', serif;">
            💬 شاركنا رأيك
        </h3>
        <textarea id="commentBox" placeholder="اكتب تعليقك هنا..." style="width: 100%; min-height: 150px; padding: 15px; border: 2px solid #8b45ff; border-radius: 12px; font-size: 16px; font-family: 'Tajawal', sans-serif; resize: vertical; direction: rtl; transition: all 0.3s;" onfocus="this.style.borderColor='#3b82f6'; this.style.boxShadow='0 0 15px rgba(139, 69, 255, 0.3)';" onblur="this.style.borderColor='#8b45ff'; this.style.boxShadow='none';"></textarea>
        <button onclick="submitComment()" style="display: block; margin: 20px auto 0; padding: 12px 40px; background: linear-gradient(135deg, #8b45ff, #3b82f6); color: white; border: none; border-radius: 25px; font-size: 18px; font-weight: bold; cursor: pointer; transition: all 0.3s; font-family: 'Tajawal', sans-serif;" onmouseover="this.style.transform='translateY(-3px)'; this.style.boxShadow='0 10px 25px rgba(139, 69, 255, 0.4)';" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none';">
            ✉️ أرسل تعليقك
        </button>
        <div id="commentStatus" style="margin-top: 15px; text-align: center; font-size: 16px; font-family: 'Tajawal', sans-serif;"></div>
    </div>

    <script>
    function submitComment() {
        const commentBox = document.getElementById('commentBox');
        const statusDiv = document.getElementById('commentStatus');
        const comment = commentBox.value.trim();
        
        if (comment === '') {
            statusDiv.innerHTML = '<span style="color: #ef4444;">⚠️ الرجاء كتابة تعليق قبل الإرسال</span>';
            setTimeout(() => { statusDiv.innerHTML = ''; }, 3000);
            return;
        }
        
        statusDiv.innerHTML = '<span style="color: #10b981;">✅ شكراً لك! تم استلام تعليقك بنجاح</span>';
        commentBox.value = '';
        
        setTimeout(() => { statusDiv.innerHTML = ''; }, 4000);
    }
    </script>
"""

def add_comments_safely(filename):
    """إضافة مربع التعليقات فقط"""
    
    filepath = os.path.join('/home/user/universe-melodies-website', filename)
    
    if not os.path.exists(filepath):
        print(f"❌ {filename} - غير موجود")
        return False
    
    # قراءة المحتوى
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # التأكد من أن الصفحة لا تحتوي على مربع تعليقات بالفعل
    if 'شاركنا رأيك' in content or 'commentBox' in content:
        print(f"⚠️ {filename} - يحتوي على تعليقات بالفعل، تم التخطي")
        return False
    
    # أخذ نسخة احتياطية
    backup_path = filepath + '.backup_comments'
    shutil.copy2(filepath, backup_path)
    
    # البحث عن أزرار التنقل لإضافة التعليقات قبلها
    # نبحث عن النص "الفصل السابق" أو "الصفحة الرئيسية"
    nav_markers = ['الفصل السابق', 'الصفحة الرئيسية', 'الفصل التالي']
    
    insertion_point = None
    for marker in nav_markers:
        pos = content.find(marker)
        if pos != -1:
            # نبحث عن بداية الـ div أو الـ a tag الذي يحتوي على هذا النص
            # نبحث للخلف حتى نجد <div أو <a
            search_start = max(0, pos - 500)  # نبحث في 500 حرف قبل النص
            section = content[search_start:pos]
            
            # البحث عن آخر <div أو <a قبل النص
            last_div = section.rfind('<div')
            last_a = section.rfind('<a ')
            
            if last_div != -1 or last_a != -1:
                insertion_point = search_start + max(last_div, last_a)
                break
    
    if insertion_point is None:
        # إذا لم نجد، نضيف قبل </body>
        if '</body>' in content:
            insertion_point = content.rfind('</body>')
        else:
            print(f"❌ {filename} - لم يتم العثور على نقطة إدراج مناسبة")
            os.remove(backup_path)
            return False
    
    # الإضافة
    new_content = content[:insertion_point] + COMMENTS_TEMPLATE + '\n' + content[insertion_point:]
    
    # حفظ الملف
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(new_content)
    
    print(f"✅ {filename} - تمت إضافة مربع التعليقات")
    return True

def main():
    """إضافة مربع التعليقات للصفحات المحددة"""
    
    # الصفحات التي تحتوي على أزرار لكن بدون تعليقات
    pages_to_update = [
        'chapter3.html',
        'chapter4.html',
        'chapter12.html',
        'chapter13.html',
        'chapter14.html',
        'chapter15.html',
        'conclusion.html',
    ]
    
    print("=" * 70)
    print("بدء إضافة مربع التعليقات...")
    print("=" * 70)
    print(f"الصفحات المستهدفة: {len(pages_to_update)}")
    print()
    
    success_count = 0
    
    for page in pages_to_update:
        if add_comments_safely(page):
            success_count += 1
    
    print()
    print("=" * 70)
    print(f"✅ اكتمل: {success_count}/{len(pages_to_update)} صفحة تم تحديثها")
    print("=" * 70)

if __name__ == '__main__':
    main()

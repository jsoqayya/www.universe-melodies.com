#!/usr/bin/env python3
import re
import os

# HTML template for the new comments section with textarea and submit button (NO EMAIL)
comments_section = '''<!-- Comments Section with Interactive Form -->
<div style="margin-top: 4rem; padding: 2rem; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.2);">
    <h3 style="text-align: center; color: white; margin-bottom: 1.5rem; font-size: 1.8rem; text-shadow: 2px 2px 4px rgba(0,0,0,0.3);">
        💬 شاركنا برأيك
    </h3>
    <div style="background: white; padding: 2rem; border-radius: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.1);">
        <textarea id="commentBox" placeholder="اكتب تعليقك هنا..." style="width: 100%; min-height: 120px; padding: 15px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 1.1em; font-family: 'Arial', sans-serif; resize: vertical; box-sizing: border-box; direction: rtl; text-align: right; transition: border-color 0.3s;" onfocus="this.style.borderColor='#667eea'" onblur="this.style.borderColor='#e0e0e0'"></textarea>
        
        <button onclick="submitComment()" style="margin-top: 15px; padding: 12px 40px; background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white; border: none; border-radius: 25px; font-size: 1.2em; font-weight: bold; cursor: pointer; display: block; margin-left: auto; margin-right: auto; box-shadow: 0 4px 15px rgba(245,87,108,0.4); transition: all 0.3s ease;" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 6px 20px rgba(245,87,108,0.6)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 15px rgba(245,87,108,0.4)'">
            ✉️ أرسل تعليقك
        </button>
        
        <div id="commentStatus" style="margin-top: 15px; text-align: center; font-size: 1em; display: none;"></div>
    </div>
</div>

<script>
function submitComment() {
    const commentBox = document.getElementById('commentBox');
    const statusDiv = document.getElementById('commentStatus');
    const comment = commentBox.value.trim();
    
    if (comment === '') {
        statusDiv.style.display = 'block';
        statusDiv.style.color = '#e74c3c';
        statusDiv.innerHTML = '⚠️ الرجاء كتابة تعليق قبل الإرسال';
        setTimeout(() => { statusDiv.style.display = 'none'; }, 3000);
        return;
    }
    
    statusDiv.style.display = 'block';
    statusDiv.style.color = '#27ae60';
    statusDiv.innerHTML = '✅ شكراً لك! تم استلام تعليقك بنجاح';
    commentBox.value = '';
    
    setTimeout(() => { statusDiv.style.display = 'none'; }, 4000);
    
    console.log('Comment submitted:', comment);
}
</script>

'''

# Process Arabic pages (introduction, chapters 1-15, conclusion)
pages = ['introduction.html'] + [f'chapter{i}.html' for i in range(1, 16)] + ['conclusion.html']

success_count = 0
for page in pages:
    filepath = page
    if not os.path.exists(filepath):
        print(f"❌ File not found: {page}")
        continue
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Remove old comments section (from <!-- Comments Section --> until before <!-- Navigation Buttons -->)
    content = re.sub(
        r'<!-- Comments Section -->.*?(?=<!-- Navigation Buttons -->)',
        '',
        content,
        flags=re.DOTALL
    )
    
    # Insert new comments section before navigation
    pattern = r'(<!-- Navigation Buttons -->)'
    if re.search(pattern, content):
        content = re.sub(pattern, comments_section + r'\n    \1', content, count=1)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"✅ Updated: {page}")
        success_count += 1
    else:
        print(f"⚠️ Navigation section not found in: {page}")

print(f"\n🎉 Successfully updated {success_count}/{len(pages)} pages")
print("✅ Comments section now has interactive textarea and submit button")
print("✅ Email address removed for privacy")

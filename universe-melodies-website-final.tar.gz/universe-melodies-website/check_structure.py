#!/usr/bin/env python3
import re

# Check chapters 6-15 for proper structure
chapters = [f'chapter{i}.html' for i in range(6, 16)]

print("=" * 70)
print("📋 فحص هيكل الفصول (6-15)")
print("=" * 70)

for chapter in chapters:
    with open(chapter, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Find all occurrences of key sections
    comments_matches = list(re.finditer(r'💬 شاركنا برأيك', content))
    nav_matches = list(re.finditer(r'<!-- Navigation Buttons -->', content))
    footer_matches = list(re.finditer(r'<footer', content))
    
    print(f"\n📄 {chapter}:")
    print(f"   📝 مربعات التعليق: {len(comments_matches)}")
    print(f"   🔘 أزرار التنقل: {len(nav_matches)}")
    print(f"   📍 Footer: {len(footer_matches)}")
    
    # Check the order of elements
    if comments_matches and nav_matches:
        comment_pos = comments_matches[0].start()
        nav_pos = nav_matches[0].start()
        
        if comment_pos < nav_pos:
            print(f"   ✅ الترتيب صحيح: التعليقات ← التنقل")
        else:
            print(f"   ⚠️ الترتيب خاطئ: التنقل قبل التعليقات!")
    
    # Check for any duplicate sections (appearing in middle of content)
    lines = content.split('\n')
    comment_lines = [i for i, line in enumerate(lines) if '💬 شاركنا برأيك' in line]
    nav_lines = [i for i, line in enumerate(lines) if '<!-- Navigation Buttons -->' in line]
    
    if len(comment_lines) > 1:
        print(f"   ⚠️ تكرار مربع التعليقات في الأسطر: {comment_lines}")
    if len(nav_lines) > 1:
        print(f"   ⚠️ تكرار أزرار التنقل في الأسطر: {nav_lines}")

print("\n" + "=" * 70)
print("✅ انتهى الفحص")
print("=" * 70)

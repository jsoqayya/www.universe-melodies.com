#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
إضافة أزرار التنقل ومربع التعليقات بشكل آمن جداً
فقط للصفحات التي لا تحتوي عليها
"""

import os
import shutil
from datetime import datetime

# القالب الموحد
FOOTER_TEMPLATE = """
    <!-- قسم التعليقات الموحد -->
    <div style="max-width: 900px; margin: 60px auto; padding: 30px; background: linear-gradient(135deg, rgba(139, 69, 255, 0.1), rgba(59, 130, 246, 0.1)); border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); direction: rtl;">
        <h3 style="text-align: center; color: #8b45ff; font-size: 28px; margin-bottom: 20px; font-family: 'Amiri', serif;">
            💬 شاركنا رأيك
        </h3>
        <textarea id="commentBox" placeholder="اكتب تعليقك هنا..." style="width: 100%; min-height: 150px; padding: 15px; border: 2px solid #8b45ff; border-radius: 12px; font-size: 16px; font-family: 'Tajawal', sans-serif; resize: vertical; direction: rtl; transition: all 0.3s;" onfocus="this.style.borderColor='#3b82f6'; this.style.boxShadow='0 0 15px rgba(139, 69, 255, 0.3)';" onblur="this.style.borderColor='#8b45ff'; this.style.boxShadow='none';"></textarea>
        <button onclick="submitComment()" style="display: block; margin: 20px auto 0; padding: 12px 40px; background: linear-gradient(135deg, #8b45ff, #3b82f6); color: white; border: none; border-radius: 25px; font-size: 18px; font-weight: bold; cursor: pointer; transition: all 0.3s; font-family: 'Tajawal', sans-serif;" onmouseover="this.style.transform='translateY(-3px)'; this.style.boxShadow='0 10px 25px rgba(139, 69, 255, 0.4)';" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none';">
            ✉️ أرسل تعليقك
        </button>
        <div id="commentStatus" style="margin-top: 15px; text-align: center; font-size: 16px; font-family: 'Tajawal', sans-serif;"></div>
    </div>

    <script>
    function submitComment() {{
        const commentBox = document.getElementById('commentBox');
        const statusDiv = document.getElementById('commentStatus');
        const comment = commentBox.value.trim();
        
        if (comment === '') {{
            statusDiv.innerHTML = '<span style="color: #ef4444;">⚠️ الرجاء كتابة تعليق قبل الإرسال</span>';
            setTimeout(() => {{ statusDiv.innerHTML = ''; }}, 3000);
            return;
        }}
        
        statusDiv.innerHTML = '<span style="color: #10b981;">✅ شكراً لك! تم استلام تعليقك بنجاح</span>';
        commentBox.value = '';
        
        setTimeout(() => {{ statusDiv.innerHTML = ''; }}, 4000);
    }}
    </script>

    <!-- أزرار التنقل الموحدة -->
    <div style="max-width: 900px; margin: 40px auto 60px; padding: 20px; text-align: center; direction: rtl;">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
            <a href="{prev_link}" style="flex: 1; min-width: 150px; padding: 12px 25px; background: linear-gradient(135deg, #8b45ff, #3b82f6); color: white; text-decoration: none; border-radius: 25px; font-size: 16px; font-weight: bold; font-family: 'Tajawal', sans-serif; transition: all 0.3s; display: inline-block; text-align: center;" onmouseover="this.style.transform='translateY(-3px)'; this.style.boxShadow='0 10px 25px rgba(139, 69, 255, 0.4)';" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none';">
                ← الفصل السابق
            </a>
            <a href="index.html" style="flex: 1; min-width: 150px; padding: 12px 25px; background: linear-gradient(135deg, #ec4899, #f43f5e); color: white; text-decoration: none; border-radius: 25px; font-size: 16px; font-weight: bold; font-family: 'Tajawal', sans-serif; transition: all 0.3s; display: inline-block; text-align: center;" onmouseover="this.style.transform='translateY(-3px)'; this.style.boxShadow='0 10px 25px rgba(236, 72, 153, 0.4)';" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none';">
                🏠 الصفحة الرئيسية
            </a>
            <a href="{next_link}" style="flex: 1; min-width: 150px; padding: 12px 25px; background: linear-gradient(135deg, #8b45ff, #3b82f6); color: white; text-decoration: none; border-radius: 25px; font-size: 16px; font-weight: bold; font-family: 'Tajawal', sans-serif; transition: all 0.3s; display: inline-block; text-align: center;" onmouseover="this.style.transform='translateY(-3px)'; this.style.boxShadow='0 10px 25px rgba(139, 69, 255, 0.4)';" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none';">
                الفصل التالي →
            </a>
        </div>
    </div>
"""

# روابط التنقل
NAVIGATION_LINKS = {
    'introduction.html': {'prev': 'index.html', 'next': 'chapter1.html'},
    'chapter1.html': {'prev': 'introduction.html', 'next': 'chapter2.html'},
    'chapter2.html': {'prev': 'chapter1.html', 'next': 'chapter3.html'},
    'chapter5.html': {'prev': 'chapter4.html', 'next': 'chapter6.html'},
    'chapter6.html': {'prev': 'chapter5.html', 'next': 'chapter7.html'},
    'chapter7.html': {'prev': 'chapter6.html', 'next': 'chapter8.html'},
    'chapter8.html': {'prev': 'chapter7.html', 'next': 'chapter9.html'},
    'chapter9.html': {'prev': 'chapter8.html', 'next': 'chapter10.html'},
    'chapter11.html': {'prev': 'chapter10.html', 'next': 'chapter12.html'},
}

def add_footer_safely(filename):
    """إضافة القالب بشكل آمن جداً - فقط إضافة قبل </body>"""
    
    if filename not in NAVIGATION_LINKS:
        print(f"⚠️ {filename} - ليس في القائمة")
        return False
    
    filepath = os.path.join('/home/user/universe-melodies-website', filename)
    
    if not os.path.exists(filepath):
        print(f"❌ {filename} - غير موجود")
        return False
    
    # أخذ نسخة احتياطية
    backup_path = filepath + '.backup_safe'
    shutil.copy2(filepath, backup_path)
    
    # قراءة المحتوى
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # التأكد من أن الصفحة لا تحتوي على أزرار بالفعل
    if 'الفصل السابق' in content or 'الفصل التالي' in content:
        print(f"⚠️ {filename} - يحتوي على أزرار بالفعل، تم التخطي")
        os.remove(backup_path)
        return False
    
    # إعداد القالب
    links = NAVIGATION_LINKS[filename]
    footer = FOOTER_TEMPLATE.replace('{prev_link}', links['prev']).replace('{next_link}', links['next'])
    
    # الإضافة بشكل آمن - فقط قبل </body>
    if '</body>' in content:
        # البحث عن آخر </body>
        last_body = content.rfind('</body>')
        if last_body != -1:
            new_content = content[:last_body] + footer + '\n' + content[last_body:]
        else:
            print(f"❌ {filename} - لم يتم العثور على </body>")
            os.remove(backup_path)
            return False
    else:
        print(f"❌ {filename} - لا يحتوي على </body>")
        os.remove(backup_path)
        return False
    
    # حفظ الملف
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(new_content)
    
    print(f"✅ {filename} - تمت الإضافة بنجاح")
    return True

def main():
    """تطبيق على الصفحات المحددة فقط"""
    
    # الصفحات التي تحتاج إضافة (بدون أزرار)
    pages_to_update = [
        'introduction.html',
        'chapter1.html',
        'chapter2.html',
        'chapter5.html',
        'chapter6.html',
        'chapter7.html',
        'chapter8.html',
        'chapter9.html',
        'chapter11.html',
    ]
    
    print("=" * 70)
    print("بدء الإضافة الآمنة للأزرار ومربع التعليقات...")
    print("=" * 70)
    print(f"الصفحات المستهدفة: {len(pages_to_update)}")
    print()
    
    success_count = 0
    
    for page in pages_to_update:
        if add_footer_safely(page):
            success_count += 1
    
    print()
    print("=" * 70)
    print(f"✅ اكتمل: {success_count}/{len(pages_to_update)} صفحة تم تحديثها")
    print("=" * 70)
    print()
    print("💾 ملاحظة: تم إنشاء نسخ احتياطية بامتداد .backup_safe")

if __name__ == '__main__':
    main()

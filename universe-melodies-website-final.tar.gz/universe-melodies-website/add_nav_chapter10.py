#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
إضافة أزرار التنقل فقط للفصل العاشر
"""

import os
import shutil

# أزرار التنقل فقط
NAV_BUTTONS = """
    <!-- أزرار التنقل الموحدة -->
    <div style="max-width: 900px; margin: 40px auto 60px; padding: 20px; text-align: center; direction: rtl;">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
            <a href="chapter9.html" style="flex: 1; min-width: 150px; padding: 12px 25px; background: linear-gradient(135deg, #8b45ff, #3b82f6); color: white; text-decoration: none; border-radius: 25px; font-size: 16px; font-weight: bold; font-family: 'Tajawal', sans-serif; transition: all 0.3s; display: inline-block; text-align: center;" onmouseover="this.style.transform='translateY(-3px)'; this.style.boxShadow='0 10px 25px rgba(139, 69, 255, 0.4)';" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none';">
                ← الفصل السابق
            </a>
            <a href="index.html" style="flex: 1; min-width: 150px; padding: 12px 25px; background: linear-gradient(135deg, #ec4899, #f43f5e); color: white; text-decoration: none; border-radius: 25px; font-size: 16px; font-weight: bold; font-family: 'Tajawal', sans-serif; transition: all 0.3s; display: inline-block; text-align: center;" onmouseover="this.style.transform='translateY(-3px)'; this.style.boxShadow='0 10px 25px rgba(236, 72, 153, 0.4)';" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none';">
                🏠 الصفحة الرئيسية
            </a>
            <a href="chapter11.html" style="flex: 1; min-width: 150px; padding: 12px 25px; background: linear-gradient(135deg, #8b45ff, #3b82f6); color: white; text-decoration: none; border-radius: 25px; font-size: 16px; font-weight: bold; font-family: 'Tajawal', sans-serif; transition: all 0.3s; display: inline-block; text-align: center;" onmouseover="this.style.transform='translateY(-3px)'; this.style.boxShadow='0 10px 25px rgba(139, 69, 255, 0.4)';" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none';">
                الفصل التالي →
            </a>
        </div>
    </div>
"""

filepath = '/home/user/universe-melodies-website/chapter10.html'

# أخذ نسخة احتياطية
shutil.copy2(filepath, filepath + '.backup_nav')

# قراءة المحتوى
with open(filepath, 'r', encoding='utf-8') as f:
    content = f.read()

# الإضافة قبل </body>
if '</body>' in content:
    pos = content.rfind('</body>')
    new_content = content[:pos] + NAV_BUTTONS + '\n' + content[pos:]
    
    # حفظ
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(new_content)
    
    print("✅ تمت إضافة أزرار التنقل للفصل العاشر")
else:
    print("❌ لم يتم العثور على </body>")

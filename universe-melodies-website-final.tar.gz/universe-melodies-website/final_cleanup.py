#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
الإصلاح النهائي الشامل:
1. استعادة الفصل 3 و 4 من النسخة الاحتياطية
2. حذف الإضافات الجديدة من الفصل 5
3. حذف الأزرار المكررة من الفصل 8 و 9
4. حذف مربعات التعليقات الجديدة من الفصول 12 و 13 و 14
"""

import os
import shutil
import re

backup_dir = '/home/user/universe-melodies-website-backup-20251229-182623'

print("=" * 70)
print("بدء الإصلاح النهائي الشامل...")
print("=" * 70)
print()

# 1. استعادة الفصل 3 و 4
print("1️⃣ استعادة الفصل 3 و 4:")
for ch in [3, 4]:
    src = os.path.join(backup_dir, f'chapter{ch}.html')
    dst = f'/home/user/universe-melodies-website/chapter{ch}.html'
    if os.path.exists(src):
        shutil.copy2(src, dst)
        print(f"✅ chapter{ch}.html - تم استعادته من النسخة الاحتياطية")
    else:
        print(f"❌ chapter{ch}.html - لم يتم العثور على النسخة الاحتياطية")
print()

# 2. حذف الإضافات الجديدة من الفصل 5
print("2️⃣ الفصل الخامس - حذف الإضافات الجديدة:")
ch5_path = '/home/user/universe-melodies-website/chapter5.html'
with open(ch5_path, 'r', encoding='utf-8') as f:
    content = f.read()

# حذف قسم التعليقات الموحد الجديد
pattern = r'<!-- قسم التعليقات الموحد -->.*?</script>\s*'
new_content = re.sub(pattern, '', content, flags=re.DOTALL)

if new_content != content:
    with open(ch5_path, 'w', encoding='utf-8') as f:
        f.write(new_content)
    print("✅ chapter5.html - تم حذف الإضافات الجديدة")
else:
    print("⚪ chapter5.html - لم يتم العثور على إضافات جديدة")
print()

# 3. حذف الأزرار المكررة من الفصل 8 و 9
print("3️⃣ الفصل 8 و 9 - حذف الأزرار المكررة:")
for ch in [8, 9]:
    ch_path = f'/home/user/universe-melodies-website/chapter{ch}.html'
    with open(ch_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # حذف قسم التعليقات الموحد والأزرار الجديدة
    pattern = r'<!-- قسم التعليقات الموحد -->.*?</script>\s*'
    new_content = re.sub(pattern, '', content, flags=re.DOTALL)
    
    if new_content != content:
        with open(ch_path, 'w', encoding='utf-8') as f:
            f.write(new_content)
        print(f"✅ chapter{ch}.html - تم حذف التكرارات")
    else:
        print(f"⚪ chapter{ch}.html - لم يتم العثور على تكرارات")
print()

# 4. حذف مربعات التعليقات الجديدة من 12 و 13 و 14
print("4️⃣ الفصول 12 و 13 و 14 - حذف مربعات التعليقات الجديدة:")
for ch in [12, 13, 14]:
    ch_path = f'/home/user/universe-melodies-website/chapter{ch}.html'
    with open(ch_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # حذف قسم التعليقات الموحد الجديد
    pattern = r'<!-- قسم التعليقات الموحد -->.*?</script>\s*'
    new_content = re.sub(pattern, '', content, flags=re.DOTALL)
    
    if new_content != content:
        with open(ch_path, 'w', encoding='utf-8') as f:
            f.write(new_content)
        print(f"✅ chapter{ch}.html - تم حذف مربع التعليقات الجديد")
    else:
        print(f"⚪ chapter{ch}.html - لم يتم العثور على مربع جديد")
print()

print("=" * 70)
print("✅ اكتمل الإصلاح النهائي!")
print("=" * 70)
